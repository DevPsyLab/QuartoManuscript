# QuartoManuscript

This manuscript that is generated from this template codebase is posted at the following link: https://devpsylab.github.io/QuartoManuscript/.
Link the GitHub repository to [Zenodo](https://zenodo.org) for obtaining a doi (long-term storage).

The manuscript template uses the [`apaquarto` extension](https://github.com/wjschne/apaquarto).

For an example of a Quarto manuscript, see here: https://github.com/alex-koiter/riparian-grazing-manuscript (the compiled manuscript is available at: https://alexkoiter.ca/riparian-grazing-manuscript/).
