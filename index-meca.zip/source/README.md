# QuartoManuscript

This manuscript is posted at the following link: https://devpsylab.github.io/QuartoManuscript/.

The manuscript template uses the [`apaquarto` extension](https://github.com/wjschne/apaquarto).
