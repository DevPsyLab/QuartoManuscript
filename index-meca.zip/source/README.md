# QuartoManuscript

This manuscript is posted at the following link: https://devpsylab.github.io/QuartoManuscript/
