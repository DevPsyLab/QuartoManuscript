# QuartoManuscript

This manuscript is posted at the following link: https://devpsylab.github.io/QuartoManuscript/.

The manuscript template uses the [`apaquarto` extension](https://github.com/wjschne/apaquarto).

For an example of a Quarto manuscript, see here: https://github.com/alex-koiter/riparian-grazing-manuscript (the compiled manuscript is available at: https://alexkoiter.ca/riparian-grazing-manuscript/).
